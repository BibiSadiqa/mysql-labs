create database school_management;

create table students (StudentID int primary key auto_increment, firstname VARCHAR(50),Lastname VARCHAR(50),email VARCHAR(100),
date_of_birth date, Gender char(1));

create table classes (ClassID int primary key auto_increment, classname VARCHAR(50), teachername VARCHAR(50));

ALTER TABLE students ADD Phone_number VARCHAR(100);
ALTER TABLE students MODIFY COLUMN email VARCHAR(150);
ALTER TABLE students DROP COLUMN Gender;
DROP TABLE classes;
DROP database school_management;

